package professor;

public class ProfessorBean {
	private int pro_id;
	private String pro_pwd;
	private String pro_name;
	private String pro_eng_name;
	private String pro_jumin;
	private int pro_major;
	private String pro_tel;
	private String pro_addr;
	private String pro_email;
	// img추가해야함
	public int getPro_id() {
		return pro_id;
	}
	public void setPro_id(int prof_id) {
		this.pro_id = prof_id;
	}
	public String getPro_pwd() {
		return pro_pwd;
	}
	public void setPro_pwd(String pro_pwd) {
		this.pro_pwd = pro_pwd;
	}
	public String getPro_name() {
		return pro_name;
	}
	public void setPro_name(String pro_name) {
		this.pro_name = pro_name;
	}
	public String getPro_eng_name() {
		return pro_eng_name;
	}
	public void setPro_eng_name(String pro_eng_name) {
		this.pro_eng_name = pro_eng_name;
	}
	public String getPro_jumin() {
		return pro_jumin;
	}
	public void setPro_jumin(String pro_jumin) {
		this.pro_jumin = pro_jumin;
	}
	public int getPro_major() {
		return pro_major;
	}
	public void setPro_major(int pro_major) {
		this.pro_major = pro_major;
	}
	public String getPro_tel() {
		return pro_tel;
	}
	public void setPro_tel(String pro_tel) {
		this.pro_tel = pro_tel;
	}
	public String getPro_addr() {
		return pro_addr;
	}
	public void setPro_addr(String pro_addr) {
		this.pro_addr = pro_addr;
	}
	public String getPro_email() {
		return pro_email;
	}
	public void setPro_email(String pro_email) {
		this.pro_email = pro_email;
	}
	
	
	
	
}
